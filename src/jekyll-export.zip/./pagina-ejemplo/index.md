---
title: Página de ejemplo
author: muammar
layout: page
---
Esto es una página de ejemplo. Es diferente a una entrada porque permanece fija en un lugar y se mostrará en la navegación de tu sitio (en la mayoría de los temas). La mayoría de la gente empieza con una página de Acerca de, que les presenta a los potenciales visitantes del sitio. Podría ser algo como esto::

> ¡Hola! Soy mensajero por el día, aspirante a actor por la noche, y este es mi blog. Vivo en Madrid, tengo un perrazo llamado Duque y me gustan las piñas coladas (y que me pille un chaparrón)

&#8230;o algo así:

> La empresa XYZ se fundó en 1971 y ha estado ofreciendo &#8220;cosas&#8221; de calidad al público desde entonces. Situada en Madrid, XYZ emplea a más de 2.000 personas y hace todo tipo de cosas sorprendentes para la comunidad de Madrid.

Si eres nuevo en WordPress deberías ir a [tu escritorio][1] para borrar esta páginay crear páginas nuevas con tu propio contenido. ¡Pásalo bien!

 [1]: http://proyectociencia.org/blog/wp-admin/