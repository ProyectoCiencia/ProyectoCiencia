---
title: Logo de Proyecto Ciencia
author: muammar
layout: post
permalink: /?p=200
jd_tweet_this:
  - yes
wp_jd_target:
  - http://www.proyectociencia.org/blog/?p=200
wp_jd_bitly:
  - http://bit.ly/7mq3zk
categories:
  - Noticias
---
Finalmente luego de cierto tiempo se ha podido escoger el logo de Proyecto Ciencia. Luego de un [correo enviado por Alejandro Alvarez ][1]a la lista general de Proyecto Ciencia se procedió a llevar a cabo ciertas discusiones y posteriormente una votación en <http://www.doodle.com>.

Fueron propuestos un número de 10 distintos logos, y el escogido ha sido este:

<img class="aligncenter" title="Logo de Proyecto Cienia" src="http://proyectociencia.org/pipermail/general/attachments/20091110/c50b74f0/attachment-0012.png" alt="" width="443" height="235" />

En los subsiguientes días se llevará a cabo la inserción del logo en los servicios brindados por Proyecto Ciencia.

Para finalizar, el registro de votos fue el siguiente:

<pre id="comment_text_1">11/24/09 11:53:23 PM CET · Alejandro Alvarez · Participant "Alejandro Alvarez"
added
OK: 3.png
OK: 6.png
OK: 9.png
OK: 10.png

11/25/09 1:00:21 AM CET · Muammar El Khatib · Participant "Muammar El Khatib"
added
OK: 3.png
OK: 9.png
OK: 10.png

11/25/09 3:44:52 PM CET · Dario Soto (dokuro) · Participant "Dario Soto
(dokuro)" added
OK: 3.png
OK: 2.png

11/26/09 2:31:41 AM CET · Erbeth Charte · Participant "Erbeth Charte" added
OK: 3.png
OK: 10.png
OK: 4.png

11/27/09 12:23:50 AM CET · Gioconda Herrera · Participant "Gioconda Herrera"
added
OK: 6.png
OK: 9.png
OK: 10.png

11/27/09 1:58:31 PM CET · Sebastián Magrí · Participant "Sebastián Magrí" added
OK: 3.png
OK: 10.png

11/30/09 4:34:58 PM CET · fidel sanchez-bueno · Participant "fidel
sanchez-bueno" added
OK: 3.png

11/30/09 7:17:37 PM CET · Andreu Correa Casablanca · Participant "Andreu Correa
Casablanca" added
OK: 9.png
OK: 1.png

12/3/09 3:51:33 PM CET · Muammar El Khatib · Poll closed by "Muammar El Khatib"

12/3/09 3:51:41 PM CET · Muammar El Khatib · Final option selected by "Muammar
El Khatib"
3.png</pre>

 [1]: http://proyectociencia.org/pipermail/general/2009-November/000088.html