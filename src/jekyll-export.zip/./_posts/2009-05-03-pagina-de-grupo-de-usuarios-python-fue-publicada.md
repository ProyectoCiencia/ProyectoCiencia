---
title: Página de Grupo de Usuarios Python fue publicada
author: muammar
layout: post
permalink: /?p=167
categories:
  - Noticias
---
Desde el 27/04/2009 la página ha sido publicada para el uso del público en general. GUPy  es un grupo abierto de estudiantes interesados en aprender y dominar en su máxima expresión el lenguaje de programación Python. Este grupo nace en el foro de Proyecto Ciencia (<a style="text-decoration: none; font-weight: normal; color: #1b57b1;" title="http://www.proyectociencia.org/foro" href="http://www.proyectociencia.org/foro">http://www.proyectociencia.org/foro</a>) e inicia formalmente sus actividades el 27/04/2009.

<p style="text-align: left;">
  <strong>Los principales objetivos del grupo son:</strong><br /> <em><br /> 1. Aprender en su máximo nivel a programar en Python.<br /> 2. Difundir el lenguaje Python entre las comunidades de programadores.<br /> 3. Enseñar Python a todo aquel que venga a nosotros con curiosidad.<br /> 4. Enseñar la Filosofía de Python.<br /> 5. Desarrollar aplicaciones de utilidad a nuestras comunidades y liberarlas bajo licencias no privativas.<br /> 6. Liberar los código fuente de los programas desarrollados por el grupo.<br /> 7. Apoyar cualquier movimiento a favor del uso y desarrollo de software libre.<br /> 8. Disfrutar mientras programamos.</em>
</p>

*  
*

<p style="text-align: left;">
  <span style="background-color: #ffffff;"><em>Para más información visita:</em><em><a href=" http://www.proyectociencia.org/gupy"> http://www.proyectociencia.org/gupy</a></em></span>
</p>