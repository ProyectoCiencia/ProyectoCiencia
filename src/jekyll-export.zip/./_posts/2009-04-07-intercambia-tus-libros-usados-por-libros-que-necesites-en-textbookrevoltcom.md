---
title: Intercambia tus libros usados por libros que necesites en TextBookRevolt.com
author: Alejandro Alvarez
layout: post
permalink: /?p=62
categories:
  - General
tags:
  - books
  - compartir
  - gratis
  - lirbos
  - share
  - ship it
  - textbookrevolt
  - universidad
---
<a href="http://news.cnet.com/i/bto/20090223/TextbookRevolt.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img style="margin: 0px auto 10px; display: block; text-align: center; cursor: pointer; width: 150px; height: 66px;" src="http://news.cnet.com/i/bto/20090223/TextbookRevolt.jpg" border="0" alt="" /></a>  
Es un hecho notable que la mayoría de los libros universitarios son realmente costosos, y en algunos casos (Latinoamérica) difíciles de conseguir, por poseer un bajo tiraje, por ser muy técnicos o por ser publicados en el exterior. Por lo cual nace la pregunta ¿y si pudiéramos intercambiar los libros que ya no usamos, por libros que necesitemos?. He aquí donde aparece TextBookRevolt ([http://www.textbookrevolt.com][1]), un sitio web nacido por el interés de un grupo de personas en ayudar a los estudiantes en la adquisición de los costosos libros, necesarios para el desarrollo de sus carreras y/o estudios.  
El registro es bastante intuitivo, en caso de no poseer un correo .edu, es necesario escribir un e-mail a <support@socialbib.com>.

<span style="font-weight: bold;">Una vez registrado los pasos son los siguientes:</span>  
1. Agrega los libros (nuevos o usados) que quieras donar.  
2. Agrega los libros que necesitas o quisieras recibir.  
3. Obtiene los libros donados por otros estudiantes / Envía los libros que donaste a los estudiantes que los necesitan.

<span style="font-weight: bold;">Sitio Web Oficial:</span>  
[http://www.textbookrevolt.com][1]

<span style="font-weight: bold;">TextBookRevolt en FaceBook:</span>  
<http://www.facebook.com/apps/application.php?id=2573262400>

 [1]: http://www.textbookrevolt.com/