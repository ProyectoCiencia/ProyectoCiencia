---
title: Cumpleaños de ProyectoCiencia.org
author: Alejandro Alvarez
layout: post
permalink: /?p=118
categories:
  - General
tags:
  - Actualizaciones
  - Celebración
  - Cumpleaños
  - Innovación
  - ProyectoCiencia.Org
---
El próximo 21 de Septiembre, ProyectoCiencia.Org cumplirá su primer año en la web. Para celebrar esto se pretenden inaugurar algunos servicios y publicaciones, entre los que están:

&#8211; Revistas Electrónicas

&#8211; Cursos de Programación con Python

&#8211; Cursos de Django

&#8211; Cursos de Latex

También se esta trabajando en el foro, para mejorar la experiencia usuario &#8211; usuario. Se están planificando las cosas y se realizan los cambios poco a poco. Se irá informando de los avances en los próximos días.