---
title: I Jornadas de Software Libre Altos Mirandinos
author: Alejandro Alvarez
layout: post
permalink: /?p=188
categories:
  - Computación
tags:
  - Altos Mirandinos
  - GNU
  - I Jornadas de Software Libre
  - Intevep
  - IVIC
  - Linux
  - PDVSA
  - Software Libre
---
<span style="color: #999999;"><em>Fuente: Prensa Web RNV/PDVSA 20 Octubre 2009, 11:39 AM</em></span>

<span style="color: #999999;"><em>http://www.rnv.gov.ve/noticias/index.php?act=ST&f=14&t=111094</em></span>

<span style="color: #999999;"><em><br /> </em></span>

<span style="color: #999999;"><em><img class="aligncenter size-medium wp-image-84" title="I Jornadas de SL" src="http://thedynamicist.wordpress.com/files/2009/11/i-jornadas-de-sl.jpg?w=300" alt="Jornadas de Software Libre - Altos Mirandinos" width="300" height="59" /><br /> </em></span>

Con la intención de sensibilizar a estudiantes, profesionales, comunidades organizadas y público en general en el uso del Software Libre a fin de consolidar la independencia tecnológica, se realizarán las I Jornadas de Software Libre Altos Mirandinos, del 6 al 7 de noviembre del presente año en las instalaciones del Inst<span style="background-color: #ffffff;">ituto Autónomo Municipal del Deporte y la Recreación, conocido también como Palacio del Deporte, en el municipio Guaicaipuro del estado Miranda. Este evento organizado por PDVSA Intevep, Alcaldía del Municipio Guaicaipuro, Instituto Venezolano de Investigaciones Científicas (IVIC) y el Metro de Los Teques, busca brindar a los asistentes información acerca del uso, ventajas, herramientas y facilidades que ofrece el software libre,</span>

además de propiciar el acercamiento gobierno- comunidad con relación a las tecnologías de la información y comunicación impulsadas por el Gobierno Bolivariano. Durante dos días de actividades las personas podrán disfrutar de presentaciones alusivas al manejo y bondades de las herramientas del Software Libre, exposición de stands, instalación de GNU/LINUX, demostraciones de hardware y software, rifas, eventos musicales y culturales, pintacaritas, entre otras atracciones.

**Fecha:** Del 6 al 7 de noviembre

**Lugar:** Palacio del Deporte, entrada

<p style="text-align: center;">
  <img class="aligncenter" title="Linux venezuela" src="http://www.haller.com.ve/cursos/file.php/1/velug2.png" alt="Tux Venezolano" width="100" height="121" />
</p>