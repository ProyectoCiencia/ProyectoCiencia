---
title: X Congreso Internacional de Métodos Numéricos en Ingeniería y Ciencias Aplicadas (CIMENICS).
author: Alejandro Alvarez
layout: post
permalink: /?p=133
categories:
  - General
  - Matemática
tags:
  - Aplicadas
  - Ciencias
  - CIMENICS
  - Congreso
  - ingenieria
  - Internacional
  - matemáticas
  - Métodos
  - Numéricos
---
[<img class="aligncenter" title="CIMENICS" src="http://www.cimenics.org.ve/images/top1.jpg" alt="" width="409" height="86" />][1]

Es un evento consolidado a nivel internacional y nacional, único en su tipo en Venezuela y uno de los pocos que existen en Latinoamérica. Se caracteriza por poseer gran poder de convocatoria a investigadores y profesionales de Venezuela y el resto del mundo, proporcionando a nuestro país un Foro reconocido por su calidad y su excelente organización.

**Fecha:** marzo 22, 2010 – marzo 24, 2010  
** Lugar:** Venezuela / Estado Mérrida / Hotel Belensate

Para mas información visite: <a title="CIMENICS DESDE PROYECTOCIENCIA" href="http://www.cimenics.org.ve" target="_blank">http://www.cimenics.org.ve</a>

 [1]: http://www.cimenics.org.ve/