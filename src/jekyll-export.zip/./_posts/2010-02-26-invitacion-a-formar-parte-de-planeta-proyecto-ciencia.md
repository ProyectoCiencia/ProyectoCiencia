---
title: Invitación para formar parte de Planeta Proyecto Ciencia
author: muammar
layout: post
permalink: /?p=241
jd_tweet_this:
  - yes
wp_jd_target:
  - http://www.proyectociencia.org/blog/?p=241
wp_jd_bitly:
  - http://bit.ly/aVU9Vo
categories:
  - Biología
  - Computación
  - Física
  - General
  - Matemática
  - Noticias
  - Química
tags:
  - ciencia
  - colaborar
  - ingenieria
  - participación
  - planeta
  - proyecto
---
<div id="_mcePaste">
  El motivo de este mensaje es invitarlos a participar en Planeta Proyecto Ciencia¹, el cual es un agregador de feeds a blogs.
</div>

<div id="_mcePaste">
  Algunos ejemplos de planetas reconocidos:
</div>



<div id="_mcePaste">
  1)<a href="http://planet.debian.org/es"> http://planet.debian.org/es</a>
</div>

<div id="_mcePaste">
  2) <a href="http://ve.planetalinux.org/">http://ve.planetalinux.org/</a>
</div>

<div id="_mcePaste">
  3) <a href="http://planet.ubuntu.com">http://planet.ubuntu.com</a>
</div>



<div id="_mcePaste">
  Por lo tanto, si tienes un blog el cual te gustaría que agregáramos, entonces no dudes en enviar la siguiente información:
</div>



<div id="_mcePaste">
  1) Nombre
</div>

<div id="_mcePaste">
  2) Feed para el blog
</div>

<div id="_mcePaste">
  3) Hackergotchi² (opcional)
</div>



<div id="_mcePaste">
  Como política preliminar, se requiere que los tópicos publicados sean acerca de ingeniería, ciencias, o computación. Por lo tanto se
</div>

<div id="_mcePaste">
  agradecería bastante que el feed sea lo más filtrado como sea posible. Sin embargo, es importante destacar que los planetas brindan
</div>

<div>
  la posibilidad de publicar vivencias propias de los individuos que la componen. Los interesados favor comunicarse a la dirección:</br> <a href="mailto:muammar@proyectociencia.org">muammar@proyectociencia.org</a>.
</div>



<div>
  Planeta Proyecto Ciencia ya está On Line y lo puedes visitar en: </br><a href="http://www.proyectociencia.org/planeta">http://www.proyectociencia.org/planeta</a>
</div>



<div id="_mcePaste">
  1.<a href="http://en.wikipedia.org/wiki/Planet_(software)"> http://en.wikipedia.org/wiki/Planet_(software)</a>
</div>

<div id="_mcePaste">
  2. <a href="http://en.wikipedia.org/wiki/Hackergotchi">http://en.wikipedia.org/wiki/Hackergotchi</a>
</div>



<div>
  Texto extraído de http://proyectociencia.org/pipermail/gupy/2010-February/000327.html
</div>