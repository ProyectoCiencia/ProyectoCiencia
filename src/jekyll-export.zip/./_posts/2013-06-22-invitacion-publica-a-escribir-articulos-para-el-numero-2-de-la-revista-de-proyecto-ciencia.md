---
title: Invitación pública a escribir artículos para el número 2 de la Revista de Proyecto Ciencia
author: muammar
layout: post
permalink: /?p=275
categories:
  - Noticias
---
Nos complace invitarlos a escribir artículos para el próximo número de la Revista Proyecto Ciencia.

Esta revista es una publicación internacional trimestral, online, de libre acceso y arbitrada orientada a la publicación de artículos cientíﬁco-técnicos principalmente divulgativos. Los artículos son publicados bajo la licencia Creative Commons Attribution license por defecto, a menos que los autores indiquen lo contrario en cuyo caso deben escoger e indicar alguna otra licencia para la publicación de sus contenidos.

Toda la información que necesitas saber se encuentra en:

<http://proyectociencia.org/revista/>

Si deseas leer el número anterior visita:

<http://proyectociencia.org/revista/publicaciones/2013-1/>

Cualquier duda puedes escribirnos via nuestra página de contacto:

<http://proyectociencia.org/contacto/>