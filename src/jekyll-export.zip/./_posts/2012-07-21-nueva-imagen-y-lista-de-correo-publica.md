---
title: Nueva imagen y lista de correo pública
author: muammar
layout: post
permalink: /?p=253
categories:
  - Noticias
---
<p style="text-align: left;">
  Ha sido un tiempo ya desde que no hemos escrito en el blog. En esta ocasión es grato anunciar que hemos lanzado una nueva imagen de  <a href="http://proyectociencia.org">Proyecto Ciencia</a>. El nuevo diseño es minimalista, y da un toque más moderno reemplazando al anterior que lucía un poco anticuado. Todos los servicios restan intactos. Como siempre, están invitados a participar en esta comunidad y para ello, pueden revisar el artículo que habla respecto a las <a href="http://proyectociencia.org/como-colaborar/">colaboraciones</a>.
</p>

<p style="text-align: left;">
  En otro orden de ideas, es también importante anunciar que la lista de correo que era antes solo de uso privado ha sido ahora publicada para acceso de todos. Pueden <a href="http://proyectociencia.org/cgi-bin/mailman/listinfo/n-proyecto  ">suscribirse</a> y ver toda la actividad que ha habido desde hace un par de años en los <a href="http://proyectociencia.org/pipermail/n-proyecto/">archivos</a> de la misma.
</p>

<p style="text-align: left;">
  Adicionalmente, y para completar esta pequeña nota, se hace de nuevo un llamado a aquellas personas que mantengan un blog a proveer su RSS para poder ser sindicados en <a href="http://proyectociencia.org/planeta">Planeta Proyecto Ciencia</a>. La única condición para poder ser agregados, es que los blogs estén relacionados a Ciencia, Ingeniería, y Tecnologías. Aquellos que estén interesados, pueden enviar un correo a info [at] proyectociencia.org o suscribirse a la lista de correos mencionada anteriormente.
</p>