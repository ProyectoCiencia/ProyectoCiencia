---
title: Proyecto Ciencia en twitter
author: muammar
layout: post
permalink: /?p=196
jd_tweet_this:
  - yes
wp_jd_target:
  - http://www.proyectociencia.org/blog/?p=196
wp_jd_bitly:
  - http://bit.ly/4qe1Wz
categories:
  - Noticias
---
Hemos creado una cuenta en twitter para aquellos que usen dicho servicio. La URL es:

<http://www.twitter.com/proyectociencia>