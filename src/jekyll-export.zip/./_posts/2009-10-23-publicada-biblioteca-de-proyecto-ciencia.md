---
title: Publicada Biblioteca de Proyecto Ciencia
author: muammar
layout: post
permalink: /?p=156
categories:
  - Noticias
tags:
  - biblioteca
  - descargas
  - gratis
  - libros
---
Gracias a los esfuerzos continuos de los miembros de Proyecto Ciencia, hemos hecho oficial el lanzamiento de un nuevo servicio a nuestra nube, una [Biblioteca][1] On-Line para el uso de la comunidad.

<span style="background-color: #ffffff;">Los formatos en que podrán ser descargados los libros son: </span>

<span style="background-color: #ffffff;"> 1) PDF<br /> 2) DJVU<br /> 3) DOC<br /> 4) LIT<br /> 5) RTF</span>

<span style="background-color: #ffffff;"> Para más información visita:</span>

<span style="background-color: #ffffff;"><a href="http://proyectociencia.org/biblioteca/?q=node/9">http://proyectociencia.org/biblioteca/?q=node/9</a></span>

 [1]: http://www.proyectociencia.org/biblioteca