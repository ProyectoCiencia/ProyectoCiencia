---
title: Proyecto Ciencia publica el primer número de su revista
author: muammar
layout: post
permalink: /?p=270
categories:
  - Noticias
---
**

Es con gran placer que les presentamos el primer número de la Revista Proyecto Ciencia. La Revista del Proyecto Ciencia es una publicación internacional trimestral, online, de libre acceso y arbitrada orientada a la publicación de artículos cientíﬁco-técnicos principalmente divulgativos. Los artículos son publicados bajo la licencia Creative Commons Attribution license por defecto, a menos que los autores indiquen lo contrario en cuyo caso deben escoger e indicar alguna otra licencia para la publicación de sus contenidos. Para más información, pueden visitar:

<http://proyectociencia.org/revista/>

Para ver la lista de artículos publicados en este número, visita:

<http://proyectociencia.org/revista/publicaciones/2013-1/>