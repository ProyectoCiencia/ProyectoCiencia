---
title: 'ICM2010 &#8211; Congreso Internacional de Matemáticos'
author: Alejandro Alvarez
layout: post
permalink: /?p=142
categories:
  - General
  - Matemática
tags:
  - Congreso
  - ICM2010
  - Internacional
  - Matemáticos
---
<img class="aligncenter" title="ICM" src="http://www.austms.org.au/myimages/w/d19cbd52ba426e272535f78449ab77ac.jpg" alt="" width="321" height="192" />

El Congreso Internacional de Matemáticos (ICM) es el mayor congreso en la comunidad matemática. Se celebra una vez cada cuatro años bajo los auspicios de la Unión Matemática Internacional (IMU por sus siglas en Inglés). Las Medallas Fields, el Premio Nevanlinna, y el Premio Gauss se conceden durante la ceremonia de apertura del Congreso. En el 2010 ICM, un nuevo premio también será otorgado, La Medalla de Chern.

**Fecha**  
Del 19 &#8211; 27 de Agosto de 2010.

**Lugar**  
El lugar de celebración del ICM-2010 será el Hyderabad International Convention Centre, Hyderabad &#8211; India.

Para mayor información visite el sitio web oficial del ICM 2010:

<a title="ICM2010" href="http://www.icm2010.org.in/index.php" target="_blank">http://www.icm2010.org.in/index.php</a>