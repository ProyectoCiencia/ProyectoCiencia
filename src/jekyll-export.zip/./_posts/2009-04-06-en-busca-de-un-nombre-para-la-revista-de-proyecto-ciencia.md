---
title: En busca de un nombre para la revista de Proyecto Ciencia
author: muammar
layout: post
permalink: /?p=177
categories:
  - Noticias
---
<p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
  <span style="font-family: arial, helvetica, sans-serif;">En Proyecto Ciencia estamos creando una revista digital. Para ello, estamos llevando a cabo un pequeño debate para elegir el nombre.  Si tienes un nombre que proponer no dudes en enviarnos tu proposición a info@proyectociencia.org</span>
</p>

<p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
  <span style="font-family: arial, helvetica, sans-serif;"><br /> </span>
</p>

<p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
  <span style="font-family: arial, helvetica, sans-serif;">Si quieres aportar ideas de manera menos unidireccional, puedes acceder al siguiente URL: <a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://www.proyectociencia.org/foro/index.php?topic=113.0" target="_blank">http://www.proyectociencia.org/foro/index.php?topic=113.0</a></span>
</p>

<p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
  <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
    <span style="font-family: arial, helvetica, sans-serif;">Por cuestiones de preparar bien el sitio de la revista digital, no estaremos revelando por los momentos el URL del mismo. En cuanto esté listo el nombre, revelaremos todos los detalles al respecto.</span>
  </p>
  
  <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
    <span style="font-family: arial, helvetica, sans-serif;"><br /> </span>
  </p>
  
  <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
    <span style="font-family: arial, helvetica, sans-serif;">Es importante destacar que  si el nombre que tu proveas fuera escogido, tus datos aparecerán en la sección de <a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://proyectociencia.org/index.php/gente" target="_blank">gente</a> como colaborador del nombre de la Revista.</span>
  </p>
  
  <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
    <span style="font-family: arial, helvetica, sans-serif;"><br /> </span>
  </p>
  
  <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
    <span style="font-family: arial, helvetica, sans-serif;">Esperamos tus sugerencias.</span>
  </p>