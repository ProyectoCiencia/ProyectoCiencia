---
title: Cómo compilar Gaussian 03 en Debian AMD 64
author: muammar
layout: post
permalink: /?p=191
jd_tweet_this:
  - yes
wp_jd_target:
  - 
categories:
  - Computación
  - Química
---
He publicado en el Wiki de Proyecto Ciencia cómo  compilar e instalar Gaussian 2003:

[http://proyectociencia.org/Wiki/index.php/Compilar\_e\_Instalar\_Gaussian\_03\_en\_Debian_AMD64][1]

Se explica paso a paso cómo compilar e instalar PGI Fortran y luego cómo compilar e instalar Gaussian 03. También se explican los pasos para configurar el ambiente BASH de los usuarios que ejecutarán Gaussian en la estación de trabajo.

 [1]: http://proyectociencia.org/Wiki/index.php/Compilar_e_Instalar_Gaussian_03_en_Debian_AMD64