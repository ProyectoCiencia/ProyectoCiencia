---
title: ¿Como ser un matemático puro?
author: Alejandro Alvarez
layout: post
permalink: /?p=89
categories:
  - Matemática
tags:
  - Artículo
  - Como ser
  - How to be
  - Matemáticos
  - Mathematician
---
<a href="http://www.math.kent.edu/%7Esather/PHOTOS/math20.gif" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img style="margin: 0px auto 10px; display: block; text-align: center; cursor: pointer; width: 350px; height: 376px;" src="http://www.math.kent.edu/%7Esather/PHOTOS/math20.gif" border="0" alt="" /></a>  
Una pregunta bastante difícil, tendríamos que tener clara la definición de lo que es un matemático. Sin embargo algunos profesores emprenden la tarea de tratar de responder esta inmensa pregunta para guiar de manera efectiva a sus estudiantes en su desarrollo académico.

Aquí les dejo un articulo muy interesante sobre como ser un matemático:

<div style="text-align: center;">
  <a href="http://hk.geocities.com/mathphyweb/puremath.pdf">haz click aquí para bajar el artículo</a>
</div>

<div style="text-align: center;">
  .
</div>

<div style="text-align: center;">
  <div style="text-align: left;">
    Espero que lo disfruten <img src="http://proyectociencia.org/blog/wp-includes/images/smilies/simple-smile.png" alt=":-)" class="wp-smiley" style="height: 1em; max-height: 1em;" />
  </div>
</div>