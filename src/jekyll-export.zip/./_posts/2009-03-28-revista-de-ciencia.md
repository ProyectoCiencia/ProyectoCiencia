---
title: Revista de Ciencia
author: muammar
layout: post
permalink: /?p=46
categories:
  - General
---
En Proyecto Ciencia estamos trabajando en la creación de una revista digital. Y por ello, estamos buscando el nombre apropiado para la misma.

Se nos ha ocurrido que sería mejor preguntarte a tí, qué nombre sería apropiado. Entonces hemos publicado en nuestro foro, un hilo para discutir este tema:

<a href="http://www.proyectociencia.org/foro/index.php?topic=113.0" target="_blank">http://www.proyectociencia.org/foro/index.php?topic=113.0</a>

Si crees que tienes un nombre bueno para proponer, no dudes en registrarte en el foro y plasmarlo en el link que fue colocado arriba. También puedes escribirnos a la dirección: <info@proyectociencia.org>. El nombre que sea elegido se anunciará por este medio, y la persona que haya enviado el nombre aparecerá en la sección <a href="http://proyectociencia.org/index.php/gente" target="_blank">Gente</a> de Proyecto Ciencia.

Esperamos ansiosamente todas las proposiciones posibles.