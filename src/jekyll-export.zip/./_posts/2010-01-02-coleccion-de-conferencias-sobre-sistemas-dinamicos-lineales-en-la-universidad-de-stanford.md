---
title: Colección de Conferencias sobre Sistemas Dinámicos Lineales en la Universidad de Stanford
author: Alejandro Alvarez
layout: post
permalink: /?p=206
wp_jd_bitly:
  - http://bit.ly/7vAlSI
wp_jd_target:
  - http://www.proyectociencia.org/blog/?p=206
jd_tweet_this:
  - yes
categories:
  - Matemática
tags:
  - conferencias
  - dynamical systems
  - sistemas dinámicos
  - stanford university
  - videos
---
<p style="text-align: left;">
  Investigando un poco sobre documentales sobre sistemas dinámicos en la red, me encontré con una colección de conferencias dictadas en la Universidad de Stanford. Son en total 20 capítulos, cada uno con una duración promedio de 1 hrs : 20 min. Espero que los disfruten tanto como yo:
</p>

<p style="text-align: center;">
  <strong>Conferencia Nº1</strong>
</p>

<p style="text-align: center;">
</p>

<p style="text-align: center;">
  <p style="text-align: center;">
    <strong>Conferencia Nº2</strong>
  </p>
  
  <p style="text-align: center;">
  </p>
  
  <p style="text-align: center;">
    <p style="text-align: center;">
      <strong>Conferencia Nº3</strong>
    </p>
    
    <p style="text-align: center;">
    </p>
    
    <p style="text-align: center;">
      <p style="text-align: center;">
        <strong>Conferencia Nº4</strong>
      </p>
      
      <p style="text-align: center;">
      </p>
      
      <p style="text-align: center;">
        <p style="text-align: center;">
          <strong>Conferencia Nº5</strong>
        </p>
        
        <p style="text-align: center;">
        </p>
        
        <p style="text-align: center;">
          <p style="text-align: center;">
            <strong>Conferencia Nº6</strong>
          </p>
          
          <p style="text-align: center;">
          </p>
          
          <p style="text-align: center;">
            <p style="text-align: center;">
              <strong>Conferencia Nº7</strong>
            </p>
            
            <p style="text-align: center;">
            </p>
            
            <p style="text-align: center;">
              <p style="text-align: center;">
                <strong>Conferencia Nº8</strong>
              </p>
              
              <p style="text-align: center;">
              </p>
              
              <p style="text-align: center;">
                <p style="text-align: center;">
                  <strong>Conferencia Nº9</strong>
                </p>
                
                <p style="text-align: center;">
                </p>
                
                <p style="text-align: center;">
                  <p style="text-align: center;">
                    <strong>Conferencia Nº10</strong>
                  </p>
                  
                  <p style="text-align: center;">
                  </p>
                  
                  <p style="text-align: center;">
                    <p style="text-align: center;">
                      <strong>Conferencia Nº11</strong>
                    </p>
                    
                    <p style="text-align: center;">
                    </p>
                    
                    <p style="text-align: center;">
                      <p style="text-align: center;">
                        <strong>Conferencia Nº12</strong>
                      </p>
                      
                      <p style="text-align: center;">
                      </p>
                      
                      <p style="text-align: center;">
                        <p style="text-align: center;">
                          <strong>Conferencia Nº13</strong>
                        </p>
                        
                        <p style="text-align: center;">
                        </p>
                        
                        <p style="text-align: center;">
                          <p style="text-align: center;">
                            <strong>Conferencia Nº14</strong>
                          </p>
                          
                          <p style="text-align: center;">
                          </p>
                          
                          <p style="text-align: center;">
                            <p style="text-align: center;">
                              <strong>Conferencia Nº15</strong>
                            </p>
                            
                            <p style="text-align: center;">
                            </p>
                            
                            <p style="text-align: center;">
                              <p style="text-align: center;">
                                <strong>Conferencia Nº16</strong>
                              </p>
                              
                              <p style="text-align: center;">
                              </p>
                              
                              <p style="text-align: center;">
                                <p style="text-align: center;">
                                  <strong>Conferencia Nº17</strong>
                                </p>
                                
                                <p style="text-align: center;">
                                </p>
                                
                                <p style="text-align: center;">
                                  <p style="text-align: center;">
                                    <strong>Conferencia Nº18</strong>
                                  </p>
                                  
                                  <p style="text-align: center;">
                                  </p>
                                  
                                  <p style="text-align: center;">
                                    <p style="text-align: center;">
                                      <strong>Conferencia Nº19</strong>
                                    </p>
                                    
                                    <p style="text-align: center;">
                                    </p>
                                    
                                    <p style="text-align: center;">
                                      <p style="text-align: center;">
                                        <strong>Conferencia Nº20</strong>
                                      </p>
                                      
                                      <p style="text-align: center;">
                                      </p>
                                      
                                      <p style="text-align: center;">