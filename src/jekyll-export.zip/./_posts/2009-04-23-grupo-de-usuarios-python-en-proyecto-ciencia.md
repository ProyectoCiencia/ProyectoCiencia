---
title: Grupo de Usuarios Python en Proyecto Ciencia
author: muammar
layout: post
permalink: /?p=175
categories:
  - Noticias
---
En Proyecto Ciencia hemos decidido crear un Grupo de Usuarios Python (GUPy). Por los momentos pueden ver los avances de todo lo referente a la organización del mismo en: <a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://www.proyectociencia.org/foro/index.php?topic=132">http://www.proyectociencia.org/foro/index.php?topic=132</a>

Por los momentos, hemos creado una lista de correo para el grupo de usuarios:[ http://proyectociencia.org/cgi-bin/mailman/listinfo/gupy][1]<a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="cgi-bin/mailman/listinfo/gupy"> </a>a la cual podrán suscribir sus cuentas de correo y comunicarse e interactuar en todo el proceso.

Estaremos publicando en el blog del proyecto información de interés. Esperamos que se unan a esta iniciativa.

 [1]: http://proyectociencia.org/cgi-bin/mailman/listinfo/gupy