---
title: Próximamente comenzará de nuevo el curso de Python en GUPy
author: muammar
layout: post
permalink: /?p=165
categories:
  - Noticias
---
<p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
  Se ha estado llevando a cabo un <a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://proyectociencia.org/pipermail/gupy/2009-June/000057.html" target="_blank">sondeo</a> en la <a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://proyectociencia.orgcgi-bin/mailman/listinfo/gupy" target="_blank">lista de correo</a> de <a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://proyectociencia.org/gupy" target="_blank">GUPy</a> para de esta manera poder reunir a todos los interesados en el <a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://proyectociencia.org/moodle/" target="_blank">curso de Python</a>. El sondeo contiene las siguientes preguntas:
</p>

<p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
  <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
    1) ¿Qué grado de conocimiento de Python tienes? (si les es posible a todos los suscritos responder esta pregunta, sería excelente)<br /> 2) ¿Qué días te podrías reunir para discutir y estudiar los capítulos?<br /> 3) De acuerdo con la respuesta en la pregunta 1, ¿podrías ser facilitador o mentor de los primeros capítulos?
  </p>
  
  <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
    <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
      Los organizadores del curso están por enviar un correo formal con la información recopilada hasta el momento. La idea es hacer una nivelación hasta el capítulo 5 de la guía de <a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://pyspanishdoc.sourceforge.net/tut/tut.html" target="_blank">Guido van Rossum en Español.</a>
    </p>
    
    <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
      <p style="margin-top: 0px; margin-bottom: 5px;" align="justify">
        Si quieres participar puedes escribirnos a info@proyectociencia.org comunicándonos tus inquietudes. Te recomendamos chequear la página oficial del <a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://proyectociencia.org/gupy">Grupo de Usuarios Python</a> (GUPy) o suscribirte a la lista de correos <span style="font-family: arial, helvetica, sans-serif;"><a style="text-decoration: none; font-weight: normal; color: #1b57b1;" href="http://proyectociencia.org/cgi-bin/mailman/listinfo/gupy" target="_blank">http://proyectociencia.org/cgi-bin/mailman/listinfo/gupy</a> ya que son los medios que disponemos para notificar los avances al respecto. </span>
      </p>